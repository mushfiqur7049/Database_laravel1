<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<ul class="icons">
						<li><a href="#" class="icon fa-facebook">
							<span class="label">Facebook</span>
						</a></li>
						<li><a href="#" class="icon fa-twitter">
							<span class="label">Twitter</span>
						</a></li>
						<li><a href="#" class="icon fa-youtube"> <span class="label">Youtube</span>
						</a></li>
						<li><a href="#" class="icon fa-instagram">
							<span class="label">Instagram</span>
						</a></li>
						<li><a href="#" class="icon fa-linkedin">
							<span class="label">LinkedIn</span>
						</a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; TOTO.com</li>
						<li>Design: <a href="https://www.facebook.com/Mushfiqur Rahman Rifat">MD.Mushfiqur Rahman Rifat</a>.</li>
						<li><?php echo date("d-m-Y");?></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

			<script type="text/javascript" src="js/scrolltop.js"></script>

	</body>
</html>
<?php /**PATH C:\xampp\htdocs\NBR_project\resources\views/home/footer.blade.php ENDPATH**/ ?>