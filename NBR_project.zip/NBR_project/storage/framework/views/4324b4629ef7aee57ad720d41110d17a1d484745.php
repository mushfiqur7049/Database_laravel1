<!DOCTYPE HTML>

<html>
	<head>
		<title>USER</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<?php //include 'clock.php' ?>

	</head>

	<body>


		<!-- Header -->
			<header id="header">
				<h1><a href="users.php">TOTO</a></h1>

				<ul class="navbar-nav ml-auto">
						<!-- Authentication Links -->
						<?php if(auth()->guard()->guest()): ?>

										<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>

								<?php if(Route::has('register')): ?>

												<a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>

								<?php endif; ?>
						<?php else: ?>

										<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
												<?php echo e(Auth::user()->username); ?> <span class="caret"></span>
										</a>

										<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
												<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
													 onclick="event.preventDefault();
																				 document.getElementById('logout-form').submit();">
														<?php echo e(__('Logout')); ?>

												</a>

												<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
														<?php echo csrf_field(); ?>
												</form>
										</div>
								
						<?php endif; ?>
				</ul>
				<!-- <a href="#nav">Menu</a> -->
			</header>



	<?php echo $__env->yieldContent('content'); ?>






		<!-- Main -->


		<section id="four" class="wrapper style2 special">
				<div class="inner">
					<header class="major narrow">
						<h2>Get in touch</h2>
						<p>If you want to say something about us</p>
					</header>
					<form action="" method="POST">
						<div class="container 75%">
							<div class="row uniform 50%">
								<div class="12u$">
									<textarea name="message" placeholder="Message" rows="4"></textarea>
								</div>
							</div>
						</div>
						<ul class="actions">
							<li><input type="submit" class="special" value="Submit" /></li>
							<li><input type="reset" class="alt" value="Reset" /></li>
						</ul>
					</form>
				</div>
			</section>


<?php echo $__env->make('homepage.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\NBR_project\resources\views/homepage/users.blade.php ENDPATH**/ ?>