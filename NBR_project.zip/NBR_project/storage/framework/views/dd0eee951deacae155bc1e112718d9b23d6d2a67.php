
		<!-- Nav -->
			<nav id="nav">
				<ul class="links">
					<li><a href="index.php">Home</a></li>
					<li><a href="maps.php">Location</a></li>
					<li><a href="innovation.php">Innovations</a></li>
					<li><a href="brand&product.php">Brand & products</a></li>
					<!-- <li><a href="brand&product.php">Contract</a></li> -->
					<li><a href="noticeuser.php">Noticeboard</a></li>
					<li><a href="qa.php">Comments</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="logina.php">Admin</a></li>

				</ul>
			</nav>

					
<?php /**PATH C:\xampp\htdocs\NBR_project\resources\views/home/hnav.blade.php ENDPATH**/ ?>