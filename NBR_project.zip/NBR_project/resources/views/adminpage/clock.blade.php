
<style="text-align:justify
         padding:1em 0;"> <h4> <a style="text-decoration:none;
         " href="https://www.zeitverschiebung.net/en/country/bd">
         <span style="color:gray;"></span>
        </a></h4>
  <iframe src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=en&size=small&timezone=Asia%2FDhaka"
  width="100%" height="90
 " frameborder="0" seamless>
  </iframe>
