
		<!-- Nav -->
			<nav id="nav">
				<ul class="links">
					<li><a href='/'>Home</a></li>
					<li><a href='/users'>Location</a></li>
					<li><a href="innovation.php">Innovations</a></li>
					<li><a href="brand&product.php">Brand & products</a></li>
					<!-- <li><a href="brand&product.php">Contract</a></li> -->
					<li><a href="noticeuser.php">Noticeboard</a></li>
					<li><a href='/adminlogin'>Comments</a></li>
					<li><a href='login'>Register & Login</a></li>
					<li><a href='/admin'>Admin</a></li>

				</ul>
			</nav>
